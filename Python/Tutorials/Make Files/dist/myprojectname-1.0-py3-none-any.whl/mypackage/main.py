# YouTube Tutorial:
# https://youtu.be/Yt-UF7fNLJE

print("Hello Worlds")